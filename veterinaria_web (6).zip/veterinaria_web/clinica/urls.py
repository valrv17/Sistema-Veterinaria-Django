from django.urls import path
from . import views

urlpatterns = [
    # Páginas principales
    path('', views.index, name='index'),
    path('servicios/', views.servicios, name='servicios'),
    path('placeholders/', views.placeholders, name='placeholders'),
    
    # Propietarios
    path('registrar_propietario/', views.registrar_propietario, name='registrar_propietario'),
    path('lista_propietarios/', views.lista_propietarios, name='lista_propietarios'),
    path('editar_propietario/<int:pk>/', views.editar_propietario, name='editar_propietario'),
    path('eliminar_propietario/<int:pk>/', views.eliminar_propietario, name='eliminar_propietario'),
    
    # Mascotas
    path('registrar_mascota/', views.registrar_mascota, name='registrar_mascota'),
    path('lista_mascotas/', views.lista_mascotas, name='lista_mascotas'),
    path('editar_mascota/<int:pk>/', views.editar_mascota, name='editar_mascota'),
    path('eliminar_mascota/<int:pk>/', views.eliminar_mascota, name='eliminar_mascota'),
    path('historia_clinica/<int:mascota_id>/', views.historia_clinica, name='historia_clinica'),
    
    # Veterinarios
    path('registrar_veterinario/', views.registrar_veterinario, name='registrar_veterinario'),
    path('lista_veterinarios/', views.lista_veterinarios, name='lista_veterinarios'),
    path('editar_veterinario/<int:pk>/', views.editar_veterinario, name='editar_veterinario'),
    path('eliminar_veterinario/<int:pk>/', views.eliminar_veterinario, name='eliminar_veterinario'),
    
    # Medicamentos
    path('registrar_medicamento/', views.registrar_medicamento, name='registrar_medicamento'),
    path('lista_medicamentos/', views.lista_medicamentos, name='lista_medicamentos'),
    path('editar_medicamento/<int:pk>/', views.editar_medicamento, name='editar_medicamento'),
    path('eliminar_medicamento/<int:pk>/', views.eliminar_medicamento, name='eliminar_medicamento'),
    
    # Citas
    path('registrar_cita/', views.registrar_cita, name='registrar_cita'),
    path('lista_citas/', views.lista_citas, name='lista_citas'),
    path('editar_cita/<int:pk>/', views.editar_cita, name='editar_cita'),
    path('eliminar_cita/<int:pk>/', views.eliminar_cita, name='eliminar_cita'),
    
    # Cirugías
    path('registrar_cirugia/', views.registrar_cirugia, name='registrar_cirugia'),
    path('lista_cirugias/', views.lista_cirugias, name='lista_cirugias'),
    path('editar_cirugia/<int:pk>/', views.editar_cirugia, name='editar_cirugia'),
    path('eliminar_cirugia/<int:pk>/', views.eliminar_cirugia, name='eliminar_cirugia'),
    
    # Bitácoras
    path('registrar_bitacora/', views.registrar_bitacora, name='registrar_bitacora'),
    path('lista_bitacoras/', views.lista_bitacoras, name='lista_bitacoras'),
    path('editar_bitacora/<int:pk>/', views.editar_bitacora, name='editar_bitacora'),
    path('eliminar_bitacora/<int:pk>/', views.eliminar_bitacora, name='eliminar_bitacora'),
    
    # Exportación CSV
    path('exportar_propietarios_csv/', views.exportar_propietarios_csv, name='exportar_propietarios_csv'),
    path('exportar_mascotas_csv/', views.exportar_mascotas_csv, name='exportar_mascotas_csv'),
    path('exportar_medicamentos_csv/', views.exportar_medicamentos_csv, name='exportar_medicamentos_csv'),
] 