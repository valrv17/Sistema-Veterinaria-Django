from django.contrib import admin
from .models import Propietario, Mascota, Cita

@admin.register(Propietario)
class PropietarioAdmin(admin.ModelAdmin):
    list_display = ('nombre', 'telefono', 'email')
    search_fields = ('nombre', 'telefono', 'email')
    ordering = ('nombre',)
    list_per_page = 20

@admin.register(Mascota)
class MascotaAdmin(admin.ModelAdmin):
    list_display = ('nombre', 'especie', 'edad', 'propietario')
    search_fields = ('nombre', 'especie', 'propietario__nombre')
    list_filter = ('especie', 'propietario')
    ordering = ('nombre',)
    list_per_page = 20

@admin.register(Cita)
class CitaAdmin(admin.ModelAdmin):
    list_display = ('mascota', 'fecha', 'motivo', 'estado')
    search_fields = ('mascota__nombre', 'motivo')
    list_filter = ('estado', 'fecha', 'mascota__especie')
    ordering = ('-fecha',)
    list_per_page = 20

# Personalización de los nombres en el admin
admin.site.site_header = 'Administración de la Clínica Veterinaria'
admin.site.site_title = 'Panel de Administración'
admin.site.index_title = 'Bienvenido/a al Panel de Administración'
