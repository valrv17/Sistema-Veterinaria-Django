from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse, JsonResponse
from django.contrib import messages
from django.core.paginator import Paginator
from django.db.models import Q
from django.utils import timezone
from django.template.loader import render_to_string
from .models import Propietario, Mascota, Cita, Veterinario, Medicamento, Cirugia, BitacoraConsulta, RecetaMedicamento
from django import forms
import csv
import logging

# Configurar logging
logger = logging.getLogger(__name__)

# Create your views here.

def index(request):
    # Estadísticas para el dashboard
    total_mascotas = Mascota.objects.count()
    total_propietarios = Propietario.objects.count()
    total_citas_hoy = Cita.objects.filter(fecha__date=timezone.now().date()).count()
    total_cirugias_programadas = Cirugia.objects.filter(estado='programada').count()
    medicamentos_stock_bajo = Medicamento.objects.filter(cantidad_disponible__lt=10).count()
    
    context = {
        'total_mascotas': total_mascotas,
        'total_propietarios': total_propietarios,
        'total_citas_hoy': total_citas_hoy,
        'total_cirugias_programadas': total_cirugias_programadas,
        'medicamentos_stock_bajo': medicamentos_stock_bajo,
    }
    return render(request, 'clinica/index.html', context)

def servicios(request):
    return render(request, 'clinica/servicios.html')

def placeholders(request):
    context = {
        'dueño': {'nombre': 'Juan Pérez', 'telefono': '3101234567', 'direccion': 'Calle Falsa 123'},
        'mascota': {'nombre': 'Fido', 'especie': 'Perro', 'raza': 'Labrador', 'edad': 5},
        'consulta': {'fecha': '2025-06-05 10:00:00', 'motivo': 'Chequeo Anual', 'diagnostico': 'Todo en orden.'}
    }
    return render(request, 'clinica/placeholders.html', context)

# Formularios
class PropietarioForm(forms.ModelForm):
    class Meta:
        model = Propietario
        fields = ['nombre', 'telefono', 'email']

class MascotaForm(forms.ModelForm):
    class Meta:
        model = Mascota
        fields = ['nombre', 'especie', 'edad', 'propietario']

class VeterinarioForm(forms.ModelForm):
    class Meta:
        model = Veterinario
        fields = ['nombre', 'especialidad', 'telefono', 'email', 'licencia']

class MedicamentoForm(forms.ModelForm):
    class Meta:
        model = Medicamento
        fields = ['nombre', 'descripcion', 'cantidad_disponible', 'fecha_vencimiento', 'precio', 'fabricante']
        widgets = {
            'fecha_vencimiento': forms.DateInput(attrs={'type': 'date'}),
        }

class CitaForm(forms.ModelForm):
    class Meta:
        model = Cita
        fields = ['mascota', 'veterinario', 'fecha', 'motivo', 'diagnostico', 'estado']
        widgets = {
            'fecha': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
        }

class CirugiaForm(forms.ModelForm):
    class Meta:
        model = Cirugia
        fields = ['mascota', 'veterinario', 'fecha_programada', 'tipo_cirugia', 'descripcion', 'sala', 'duracion_estimada', 'estado']
        widgets = {
            'fecha_programada': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
        }

class BitacoraForm(forms.ModelForm):
    class Meta:
        model = BitacoraConsulta
        fields = ['cita', 'mascota', 'veterinario', 'peso', 'temperatura', 'observaciones', 'diagnostico', 'tratamiento', 'proxima_visita']
        widgets = {
            'proxima_visita': forms.DateInput(attrs={'type': 'date'}),
        }

# Vistas para Propietarios
def registrar_propietario(request):
    if request.method == 'POST':
        form = PropietarioForm(request.POST)
        if form.is_valid():
            propietario = form.save()
            logger.info(f"Nuevo propietario registrado: {propietario.nombre}")
            messages.success(request, f'Propietario {propietario.nombre} registrado exitosamente.')
            return redirect('lista_propietarios')
    else:
        form = PropietarioForm()
    return render(request, 'clinica/registrar_propietario.html', {'form': form})

def lista_propietarios(request):
    propietarios = Propietario.objects.all().order_by('nombre')
    return render(request, 'clinica/lista_propietarios.html', {'propietarios': propietarios})

def editar_propietario(request, pk):
    propietario = get_object_or_404(Propietario, pk=pk)
    if request.method == 'POST':
        form = PropietarioForm(request.POST, instance=propietario)
        if form.is_valid():
            form.save()
            logger.info(f"Propietario actualizado: {propietario.nombre}")
            messages.success(request, 'Propietario actualizado exitosamente.')
            return redirect('lista_propietarios')
    else:
        form = PropietarioForm(instance=propietario)
    return render(request, 'clinica/editar_propietario.html', {'form': form, 'propietario': propietario})

def eliminar_propietario(request, pk):
    propietario = get_object_or_404(Propietario, pk=pk)
    if request.method == 'POST':
        nombre = propietario.nombre
        propietario.delete()
        logger.info(f"Propietario eliminado: {nombre}")
        messages.success(request, 'Propietario eliminado exitosamente.')
        return redirect('lista_propietarios')
    return render(request, 'clinica/eliminar_propietario.html', {'propietario': propietario})

# Vistas para Mascotas
def registrar_mascota(request):
    if request.method == 'POST':
        form = MascotaForm(request.POST)
        if form.is_valid():
            mascota = form.save()
            logger.info(f"Nueva mascota registrada: {mascota.nombre}")
            messages.success(request, f'Mascota {mascota.nombre} registrada exitosamente.')
            return redirect('lista_mascotas')
    else:
        form = MascotaForm()
    return render(request, 'clinica/registrar_mascota.html', {'form': form})

def lista_mascotas(request):
    mascotas = Mascota.objects.select_related('propietario').all().order_by('nombre')
    return render(request, 'clinica/lista_mascotas.html', {'mascotas': mascotas})

def editar_mascota(request, pk):
    mascota = get_object_or_404(Mascota, pk=pk)
    if request.method == 'POST':
        form = MascotaForm(request.POST, instance=mascota)
        if form.is_valid():
            form.save()
            logger.info(f"Mascota actualizada: {mascota.nombre}")
            messages.success(request, 'Mascota actualizada exitosamente.')
            return redirect('lista_mascotas')
    else:
        form = MascotaForm(instance=mascota)
    return render(request, 'clinica/editar_mascota.html', {'form': form, 'mascota': mascota})

def eliminar_mascota(request, pk):
    mascota = get_object_or_404(Mascota, pk=pk)
    if request.method == 'POST':
        nombre = mascota.nombre
        mascota.delete()
        logger.info(f"Mascota eliminada: {nombre}")
        messages.success(request, 'Mascota eliminada exitosamente.')
        return redirect('lista_mascotas')
    return render(request, 'clinica/eliminar_mascota.html', {'mascota': mascota})

# Vistas para Veterinarios
def registrar_veterinario(request):
    if request.method == 'POST':
        form = VeterinarioForm(request.POST)
        if form.is_valid():
            veterinario = form.save()
            logger.info(f"Nuevo veterinario registrado: {veterinario.nombre}")
            messages.success(request, f'Veterinario {veterinario.nombre} registrado exitosamente.')
            return redirect('lista_veterinarios')
    else:
        form = VeterinarioForm()
    return render(request, 'clinica/registrar_veterinario.html', {'form': form})

def lista_veterinarios(request):
    veterinarios = Veterinario.objects.all().order_by('nombre')
    return render(request, 'clinica/lista_veterinarios.html', {'veterinarios': veterinarios})

def editar_veterinario(request, pk):
    veterinario = get_object_or_404(Veterinario, pk=pk)
    if request.method == 'POST':
        form = VeterinarioForm(request.POST, instance=veterinario)
        if form.is_valid():
            form.save()
            logger.info(f"Veterinario actualizado: {veterinario.nombre}")
            messages.success(request, 'Veterinario actualizado exitosamente.')
            return redirect('lista_veterinarios')
    else:
        form = VeterinarioForm(instance=veterinario)
    return render(request, 'clinica/editar_veterinario.html', {'form': form, 'veterinario': veterinario})

def eliminar_veterinario(request, pk):
    veterinario = get_object_or_404(Veterinario, pk=pk)
    if request.method == 'POST':
        nombre = veterinario.nombre
        veterinario.delete()
        logger.info(f"Veterinario eliminado: {nombre}")
        messages.success(request, 'Veterinario eliminado exitosamente.')
        return redirect('lista_veterinarios')
    return render(request, 'clinica/eliminar_veterinario.html', {'veterinario': veterinario})

# Vistas para Medicamentos
def registrar_medicamento(request):
    if request.method == 'POST':
        form = MedicamentoForm(request.POST)
        if form.is_valid():
            medicamento = form.save()
            logger.info(f"Nuevo medicamento registrado: {medicamento.nombre}")
            messages.success(request, f'Medicamento {medicamento.nombre} registrado exitosamente.')
            return redirect('lista_medicamentos')
    else:
        form = MedicamentoForm()
    return render(request, 'clinica/registrar_medicamento.html', {'form': form})

def lista_medicamentos(request):
    medicamentos = Medicamento.objects.all().order_by('nombre')
    medicamentos_vencidos = [m for m in medicamentos if m.esta_vencido()]
    medicamentos_stock_bajo = [m for m in medicamentos if m.stock_bajo()]
    
    context = {
        'medicamentos': medicamentos,
        'medicamentos_vencidos': medicamentos_vencidos,
        'medicamentos_stock_bajo': medicamentos_stock_bajo,
    }
    return render(request, 'clinica/lista_medicamentos.html', context)

def editar_medicamento(request, pk):
    medicamento = get_object_or_404(Medicamento, pk=pk)
    if request.method == 'POST':
        form = MedicamentoForm(request.POST, instance=medicamento)
        if form.is_valid():
            form.save()
            logger.info(f"Medicamento actualizado: {medicamento.nombre}")
            messages.success(request, 'Medicamento actualizado exitosamente.')
            return redirect('lista_medicamentos')
    else:
        form = MedicamentoForm(instance=medicamento)
    return render(request, 'clinica/editar_medicamento.html', {'form': form, 'medicamento': medicamento})

def eliminar_medicamento(request, pk):
    medicamento = get_object_or_404(Medicamento, pk=pk)
    if request.method == 'POST':
        nombre = medicamento.nombre
        medicamento.delete()
        logger.info(f"Medicamento eliminado: {nombre}")
        messages.success(request, 'Medicamento eliminado exitosamente.')
        return redirect('lista_medicamentos')
    return render(request, 'clinica/eliminar_medicamento.html', {'medicamento': medicamento})

# Vistas para Citas
def registrar_cita(request):
    if request.method == 'POST':
        form = CitaForm(request.POST)
        if form.is_valid():
            cita = form.save()
            logger.info(f"Nueva cita registrada: {cita}")
            messages.success(request, 'Cita registrada exitosamente.')
            return redirect('lista_citas')
    else:
        form = CitaForm()
    return render(request, 'clinica/registrar_cita.html', {'form': form})

def lista_citas(request):
    citas = Cita.objects.select_related('mascota', 'mascota__propietario', 'veterinario').all().order_by('-fecha')
    return render(request, 'clinica/lista_citas.html', {'citas': citas})

def editar_cita(request, pk):
    cita = get_object_or_404(Cita, pk=pk)
    if request.method == 'POST':
        form = CitaForm(request.POST, instance=cita)
        if form.is_valid():
            form.save()
            logger.info(f"Cita actualizada: {cita}")
            messages.success(request, 'Cita actualizada exitosamente.')
            return redirect('lista_citas')
    else:
        form = CitaForm(instance=cita)
    return render(request, 'clinica/editar_cita.html', {'form': form, 'cita': cita})

def eliminar_cita(request, pk):
    cita = get_object_or_404(Cita, pk=pk)
    if request.method == 'POST':
        cita.delete()
        logger.info(f"Cita eliminada: {cita}")
        messages.success(request, 'Cita eliminada exitosamente.')
        return redirect('lista_citas')
    return render(request, 'clinica/eliminar_cita.html', {'cita': cita})

# Vistas para Cirugías
def registrar_cirugia(request):
    if request.method == 'POST':
        form = CirugiaForm(request.POST)
        if form.is_valid():
            cirugia = form.save()
            logger.info(f"Nueva cirugía registrada: {cirugia}")
            messages.success(request, 'Cirugía registrada exitosamente.')
            return redirect('lista_cirugias')
    else:
        form = CirugiaForm()
    return render(request, 'clinica/registrar_cirugia.html', {'form': form})

def lista_cirugias(request):
    cirugias = Cirugia.objects.select_related('mascota', 'mascota__propietario', 'veterinario').all().order_by('fecha_programada')
    return render(request, 'clinica/lista_cirugias.html', {'cirugias': cirugias})

def editar_cirugia(request, pk):
    cirugia = get_object_or_404(Cirugia, pk=pk)
    if request.method == 'POST':
        form = CirugiaForm(request.POST, instance=cirugia)
        if form.is_valid():
            form.save()
            logger.info(f"Cirugía actualizada: {cirugia}")
            messages.success(request, 'Cirugía actualizada exitosamente.')
            return redirect('lista_cirugias')
    else:
        form = CirugiaForm(instance=cirugia)
    return render(request, 'clinica/editar_cirugia.html', {'form': form, 'cirugia': cirugia})

def eliminar_cirugia(request, pk):
    cirugia = get_object_or_404(Cirugia, pk=pk)
    if request.method == 'POST':
        cirugia.delete()
        logger.info(f"Cirugía eliminada: {cirugia}")
        messages.success(request, 'Cirugía eliminada exitosamente.')
        return redirect('lista_cirugias')
    return render(request, 'clinica/eliminar_cirugia.html', {'cirugia': cirugia})

# Vistas para Bitácoras
def registrar_bitacora(request):
    if request.method == 'POST':
        form = BitacoraForm(request.POST)
        if form.is_valid():
            bitacora = form.save()
            logger.info(f"Nueva bitácora registrada: {bitacora}")
            messages.success(request, 'Bitácora registrada exitosamente.')
            return redirect('lista_bitacoras')
    else:
        form = BitacoraForm()
    return render(request, 'clinica/registrar_bitacora.html', {'form': form})

def lista_bitacoras(request):
    bitacoras = BitacoraConsulta.objects.select_related('mascota', 'mascota__propietario', 'veterinario', 'cita').all().order_by('-fecha_consulta')
    return render(request, 'clinica/lista_bitacoras.html', {'bitacoras': bitacoras})

def editar_bitacora(request, pk):
    bitacora = get_object_or_404(BitacoraConsulta, pk=pk)
    if request.method == 'POST':
        form = BitacoraForm(request.POST, instance=bitacora)
        if form.is_valid():
            form.save()
            logger.info(f"Bitácora actualizada: {bitacora}")
            messages.success(request, 'Bitácora actualizada exitosamente.')
            return redirect('lista_bitacoras')
    else:
        form = BitacoraForm(instance=bitacora)
    return render(request, 'clinica/editar_bitacora.html', {'form': form, 'bitacora': bitacora})

def eliminar_bitacora(request, pk):
    bitacora = get_object_or_404(BitacoraConsulta, pk=pk)
    if request.method == 'POST':
        bitacora.delete()
        logger.info(f"Bitácora eliminada: {bitacora}")
        messages.success(request, 'Bitácora eliminada exitosamente.')
        return redirect('lista_bitacoras')
    return render(request, 'clinica/eliminar_bitacora.html', {'bitacora': bitacora})

# Vista para Historia Clínica
def historia_clinica(request, mascota_id):
    mascota = get_object_or_404(Mascota, pk=mascota_id)
    bitacoras = BitacoraConsulta.objects.filter(mascota=mascota).select_related('veterinario').order_by('-fecha_consulta')
    cirugias = Cirugia.objects.filter(mascota=mascota).select_related('veterinario').order_by('-fecha_programada')
    citas = Cita.objects.filter(mascota=mascota).select_related('veterinario').order_by('-fecha')
    
    context = {
        'mascota': mascota,
        'bitacoras': bitacoras,
        'cirugias': cirugias,
        'citas': citas,
    }
    return render(request, 'clinica/historia_clinica.html', context)

# Vistas para Exportación CSV
def exportar_propietarios_csv(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="propietarios.csv"'
    
    writer = csv.writer(response)
    writer.writerow(['ID', 'Nombre', 'Teléfono', 'Email'])
    
    propietarios = Propietario.objects.all()
    for propietario in propietarios:
        writer.writerow([propietario.id, propietario.nombre, propietario.telefono, propietario.email])
    
    logger.info("Exportación CSV de propietarios realizada")
    return response

def exportar_mascotas_csv(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="mascotas.csv"'
    
    writer = csv.writer(response)
    writer.writerow(['ID', 'Nombre', 'Especie', 'Edad', 'Propietario', 'Teléfono Propietario', 'Email Propietario'])
    
    mascotas = Mascota.objects.select_related('propietario').all()
    for mascota in mascotas:
        writer.writerow([
            mascota.id, 
            mascota.nombre, 
            mascota.especie, 
            mascota.edad,
            mascota.propietario.nombre,
            mascota.propietario.telefono,
            mascota.propietario.email
        ])
    
    logger.info("Exportación CSV de mascotas realizada")
    return response

def exportar_medicamentos_csv(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="medicamentos.csv"'
    
    writer = csv.writer(response)
    writer.writerow(['ID', 'Nombre', 'Descripción', 'Cantidad Disponible', 'Fecha Vencimiento', 'Precio', 'Fabricante'])
    
    medicamentos = Medicamento.objects.all()
    for medicamento in medicamentos:
        writer.writerow([
            medicamento.id,
            medicamento.nombre,
            medicamento.descripcion,
            medicamento.cantidad_disponible,
            medicamento.fecha_vencimiento,
            medicamento.precio,
            medicamento.fabricante
        ])
    
    logger.info("Exportación CSV de medicamentos realizada")
    return response
