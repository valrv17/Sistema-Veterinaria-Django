from django.db import models
import logging

# Configurar logging
logger = logging.getLogger(__name__)

class Propietario(models.Model):
    nombre = models.CharField(max_length=100)
    telefono = models.CharField(max_length=20)
    email = models.EmailField(unique=True)

    def __str__(self):
        return self.nombre

class Veterinario(models.Model):
    nombre = models.CharField(max_length=100)
    especialidad = models.CharField(max_length=100)
    telefono = models.CharField(max_length=20)
    email = models.EmailField(unique=True)
    licencia = models.CharField(max_length=50, unique=True)

    def __str__(self):
        return f"Dr. {self.nombre} - {self.especialidad}"

class Mascota(models.Model):
    nombre = models.CharField(max_length=100)
    especie = models.CharField(max_length=50)
    edad = models.PositiveIntegerField()
    propietario = models.ForeignKey(Propietario, on_delete=models.CASCADE, related_name='mascotas')

    def __str__(self):
        return f"{self.nombre} ({self.especie})"

class Medicamento(models.Model):
    nombre = models.CharField(max_length=100)
    descripcion = models.TextField()
    cantidad_disponible = models.PositiveIntegerField()
    fecha_vencimiento = models.DateField()
    precio = models.DecimalField(max_digits=10, decimal_places=2)
    fabricante = models.CharField(max_length=100)
    
    def __str__(self):
        return f"{self.nombre} - Stock: {self.cantidad_disponible}"
    
    def esta_vencido(self):
        from django.utils import timezone
        return self.fecha_vencimiento < timezone.now().date()
    
    def stock_bajo(self):
        return self.cantidad_disponible < 10

class Cita(models.Model):
    mascota = models.ForeignKey(Mascota, on_delete=models.CASCADE, related_name='citas')
    veterinario = models.ForeignKey(Veterinario, on_delete=models.CASCADE, related_name='citas', null=True, blank=True)
    fecha = models.DateTimeField()
    motivo = models.CharField(max_length=200)
    diagnostico = models.TextField(blank=True, null=True)
    estado = models.CharField(max_length=20, choices=[
        ('programada', 'Programada'),
        ('en_proceso', 'En Proceso'),
        ('completada', 'Completada'),
        ('cancelada', 'Cancelada'),
    ], default='programada')

    def __str__(self):
        return f"Cita de {self.mascota.nombre} - {self.fecha.strftime('%d/%m/%Y %H:%M')}"

class Cirugia(models.Model):
    mascota = models.ForeignKey(Mascota, on_delete=models.CASCADE, related_name='cirugias')
    veterinario = models.ForeignKey(Veterinario, on_delete=models.CASCADE, related_name='cirugias')
    fecha_programada = models.DateTimeField()
    tipo_cirugia = models.CharField(max_length=100)
    descripcion = models.TextField()
    sala = models.CharField(max_length=50)
    duracion_estimada = models.PositiveIntegerField(help_text="Duración en minutos")
    estado = models.CharField(max_length=20, choices=[
        ('programada', 'Programada'),
        ('en_proceso', 'En Proceso'),
        ('completada', 'Completada'),
        ('cancelada', 'Cancelada'),
    ], default='programada')
    
    def __str__(self):
        return f"Cirugía {self.tipo_cirugia} - {self.mascota.nombre} - {self.fecha_programada.strftime('%d/%m/%Y %H:%M')}"

class BitacoraConsulta(models.Model):
    cita = models.ForeignKey(Cita, on_delete=models.CASCADE, related_name='bitacoras')
    mascota = models.ForeignKey(Mascota, on_delete=models.CASCADE, related_name='bitacoras')
    veterinario = models.ForeignKey(Veterinario, on_delete=models.CASCADE, related_name='bitacoras')
    fecha_consulta = models.DateTimeField(auto_now_add=True)
    peso = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True, help_text="Peso en kg")
    temperatura = models.DecimalField(max_digits=4, decimal_places=1, null=True, blank=True, help_text="Temperatura en °C")
    observaciones = models.TextField()
    diagnostico = models.TextField()
    tratamiento = models.TextField()
    medicamentos_recetados = models.ManyToManyField(Medicamento, blank=True, through='RecetaMedicamento')
    proxima_visita = models.DateField(null=True, blank=True)
    
    def __str__(self):
        return f"Bitácora {self.mascota.nombre} - {self.fecha_consulta.strftime('%d/%m/%Y %H:%M')}"

class RecetaMedicamento(models.Model):
    bitacora = models.ForeignKey(BitacoraConsulta, on_delete=models.CASCADE)
    medicamento = models.ForeignKey(Medicamento, on_delete=models.CASCADE)
    dosis = models.CharField(max_length=100)
    frecuencia = models.CharField(max_length=100)
    duracion = models.CharField(max_length=100)
    cantidad = models.PositiveIntegerField()
    
    def __str__(self):
        return f"{self.medicamento.nombre} - {self.dosis}" 